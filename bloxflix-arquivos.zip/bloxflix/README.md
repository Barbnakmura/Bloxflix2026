# Bloxflix

Protótipo de interface de streaming com catálogo vazio.

## Arquivos
- `index.html` — estrutura da página
- `style.css` — aparência e responsividade
- `script.js` — navegação, busca e interações

## Publicar gratuitamente pelo celular com GitHub Pages
1. Entre em https://github.com e crie uma conta ou faça login.
2. Toque em **New repository**.
3. Dê o nome `bloxflix`, marque **Public** e crie o repositório.
4. Use **Add file → Upload files** e envie os três arquivos (`index.html`, `style.css` e `script.js`).
5. Abra **Settings → Pages**.
6. Em **Build and deployment**, escolha **Deploy from a branch**.
7. Selecione `main` e `/ (root)`, depois toque em **Save**.
8. Aguarde a publicação. O GitHub mostrará o endereço do site na área **Pages**.

O endereço costuma seguir o formato `https://SEU-USUARIO.github.io/bloxflix/`.
